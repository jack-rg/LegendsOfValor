/*=====================================================*/
/* Project Title: Legends Of Valor                     */
/* Course Name: GRS CS611                              */
/* Semester: Spring '21                                */
/* Project Authors:                                    */
/*    - Jack Giunta                                    */
/*    - Victoria-Rose Burke                            */
/*    - Victor Vicente                                 */
/*=====================================================*/

import Game.LegendsOfValor;

public class Main {

	// Main access method to the game
	public static void main(String[] args) {
		@SuppressWarnings("unused")
		LegendsOfValor game = new LegendsOfValor();
	}

}
